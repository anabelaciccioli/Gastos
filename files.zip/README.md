# Reporte Semanal de Gastos TSDOCS — AB Agro

Tablero web que procesa el Excel crudo de TSDOCS y genera el reporte de gastos de campo para Dirección.

## ¿Cómo funciona?

1. Bajás el Excel crudo de TSDOCS (la descarga directa de la plataforma)
2. Abrís el tablero en el navegador
3. Arrastrás el Excel o usás el botón "Subir Excel TSDOCS"
4. El tablero procesa todo automáticamente:
   - Deduplica filas por estado más avanzado (Pivot → Gerente → Analista → Verificado)
   - Clasifica por Campo, Unidad/CC y Cuenta Contable
   - Genera KPIs, tablas y gráficos

## Pasos para publicar en GitHub Pages

### 1. Crear el repositorio

1. Abrí [github.com](https://github.com) e iniciá sesión (o creá una cuenta)
2. Hacé click en el botón **"+"** (arriba a la derecha) → **"New repository"**
3. Completá:
   - **Repository name**: `gastos-tsdocs` (o el nombre que prefieras)
   - **Description**: `Reporte semanal de gastos TSDOCS — AB Agro`
   - Dejá en **Public** (necesario para GitHub Pages gratuito)
   - Tildá **"Add a README file"**
4. Click en **"Create repository"**

### 2. Subir los archivos

1. En la página del repo, hacé click en **"Add file"** → **"Upload files"**
2. Arrastrá el archivo `index.html` (este archivo)
3. En "Commit changes" escribí algo como `Agrego tablero de gastos TSDOCS`
4. Click en **"Commit changes"**

### 3. Activar GitHub Pages

1. En el repo, andá a **Settings** (engranaje, arriba a la derecha)
2. En el menú izquierdo, buscá **"Pages"**
3. En **"Source"** seleccioná **"Deploy from a branch"**
4. En **"Branch"** seleccioná **"main"** y carpeta **"/ (root)"**
5. Click en **"Save"**
6. Esperá 1-2 minutos y recargá la página
7. Aparecerá el link del tablero: `https://TU-USUARIO.github.io/gastos-tsdocs/`

## Cómo usar el tablero cada semana

1. Bajá el Excel crudo de TSDOCS (sin modificar)
2. Abrí el link del tablero
3. Arrastrá el Excel al botón "Subir Excel TSDOCS"
4. Listo — el tablero se procesa en el momento

> El Excel **no se sube a ningún servidor**. Todo el procesamiento ocurre en tu navegador, localmente. Podés usarlo incluso sin conexión a internet (después de cargar la página por primera vez).

## Secciones del tablero

| Sección | Contenido |
|---|---|
| **Resumen** | KPIs + resumen por autorizante, campo y cuenta |
| **Detalle** | Tabla completa, 1 fila por comprobante, con semáforo de estados |
| **Por autorizante** | Desglose autorizante → campo → unidad con subtotales |
| **Por campo** | Resumen 25 de Mayo / Winifreda / Ab Energía |
| **Por cuenta** | Maquinaria, Fletes, Sanidad, etc. |
| **Dashboard** | Gráficos: dona por campo, dona por autorizante, barras por cuenta |

## Lógica de procesamiento

- **Deduplicación**: TSDOCS muestra una fila por cada estado que atravesó la factura. El tablero toma UNA fila por Id Documento, eligiendo el estado más avanzado (Pivot < Gerente < Analista < Verificado).
- **Autorizante**: solo se muestra si el estado es Analista, Verificado o Gerente. Si es Pivot, aparece "Sin asignar".
- **Clasificación campo/unidad/cuenta**: basada en el detalle y la columna Sociedad del crudo.

## Fuente de datos

Descarga cruda de la plataforma TSDOCS. No requiere ningún procesamiento previo.
